const { contextBridge } = require("electron");

contextBridge.exposeInMainWorld("gokboru", {
  version: "1.0.0"
});
